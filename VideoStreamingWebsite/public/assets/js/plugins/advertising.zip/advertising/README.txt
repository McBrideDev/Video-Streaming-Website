This package contains of Codo Player Advertising Plugin system files. For setup instructions, go to codoplayer.com/plugins.

The use of software is based on Codo Player Advertising Plugin software license agreement, found under www.codoplayer.com/policy/license/advertising.

Codo Player
Copyright (C) Donato Software House